import pandas as pd
import numpy as np
import re
from typing import List, Dict, Tuple
import logging
from email.parser import Parser
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class EmailTextProcessor:
    """Utility class for processing email texts"""

    def __init__(self):
        self.email_regex = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        self.phone_regex = re.compile(r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b')
        self.url_regex = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')

    def extract_email_content(self, raw_email: str) -> Dict[str, str]:
        """Extract structured content from raw email"""
        try:
            parser = Parser()
            email_obj = parser.parsestr(raw_email)

            content = {
                'subject': email_obj.get('Subject', ''),
                'from': email_obj.get('From', ''),
                'to': email_obj.get('To', ''),
                'date': email_obj.get('Date', ''),
                'body': ''
            }

            # Extract body
            if email_obj.is_multipart():
                for part in email_obj.walk():
                    if part.get_content_type() == "text/plain":
                        content['body'] = part.get_payload()
                        break
                    elif part.get_content_type() == "text/html":
                        html_body = part.get_payload()
                        soup = BeautifulSoup(html_body, 'html.parser')
                        content['body'] = soup.get_text()
            else:
                content['body'] = email_obj.get_payload()

            return content

        except Exception as e:
            logger.error(f"Failed to parse email: {e}")
            return {'body': raw_email, 'subject': '', 'from': '', 'to': '', 'date': ''}

    def clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        if not text:
            return ""

        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)

        # Remove email signatures (common patterns)
        text = re.sub(r'--\n.*$', '', text, flags=re.MULTILINE | re.DOTALL)
        text = re.sub(r'Best regards.*$', '', text, flags=re.MULTILINE | re.DOTALL)
        text = re.sub(r'Sincerely.*$', '', text, flags=re.MULTILINE | re.DOTALL)

        # Remove quoted text (replies)
        text = re.sub(r'>.*$', '', text, flags=re.MULTILINE)

        return text.strip()

    def anonymize_pii(self, text: str) -> str:
        """Remove or anonymize PII from text"""
        # Replace emails
        text = self.email_regex.sub('[EMAIL]', text)

        # Replace phone numbers
        text = self.phone_regex.sub('[PHONE]', text)

        # Replace URLs
        text = self.url_regex.sub('[URL]', text)

        # Replace potential account numbers (8+ consecutive digits)
        text = re.sub(r'\b\d{8,}\b', '[ACCOUNT]', text)

        return text

    def segment_long_text(self, text: str, max_length: int = 500, overlap: int = 50) -> List[str]:
        """Segment long text into overlapping chunks"""
        if len(text) <= max_length:
            return [text]

        segments = []
        start = 0

        while start < len(text):
            end = start + max_length

            # Try to break at sentence boundary
            if end < len(text):
                sentence_end = text.rfind('.', start, end)
                if sentence_end != -1 and sentence_end > start + max_length // 2:
                    end = sentence_end + 1

            segment = text[start:end].strip()
            if segment:
                segments.append(segment)

            start = end - overlap

            # Prevent infinite loop
            if start >= len(text):
                break

        return segments

class LexiconExpander:
    """Expand lexicon terms with variations"""

    def __init__(self):
        self.common_variations = {
            'ing': ['', 'ed', 's'],
            'ed': ['', 'ing', 's'],
            's': ['', 'ing', 'ed']
        }

    def generate_variations(self, term: str) -> List[str]:
        """Generate common variations of a term"""
        variations = [term]

        # Add common misspellings and variations
        words = term.split()
        if len(words) == 1:
            word = words[0]

            # Common endings
            for ending, replacements in self.common_variations.items():
                if word.endswith(ending):
                    base = word[:-len(ending)]
                    for replacement in replacements:
                        variations.append(base + replacement)

        # Add hyphenated and unhyphenated versions
        if '-' in term:
            variations.append(term.replace('-', ' '))
            variations.append(term.replace('-', ''))
        elif ' ' in term:
            variations.append(term.replace(' ', '-'))
            variations.append(term.replace(' ', ''))

        return list(set(variations))

    def expand_lexicon(self, lexicon_dict: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Expand entire lexicon dictionary with variations"""
        expanded = {}

        for category, terms in lexicon_dict.items():
            expanded_terms = []
            for term in terms:
                expanded_terms.extend(self.generate_variations(term))
            expanded[category] = list(set(expanded_terms))

        return expanded

def load_email_dataset(file_path: str, format: str = 'csv') -> pd.DataFrame:
    """Load email dataset from various formats"""
    try:
        if format.lower() == 'csv':
            df = pd.read_csv(file_path)
        elif format.lower() == 'json':
            df = pd.read_json(file_path)
        elif format.lower() == 'excel':
            df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported format: {format}")

        # Validate required columns
        required_cols = ['text']  # Minimum requirement
        if not all(col in df.columns for col in required_cols):
            raise ValueError(f"Dataset must contain columns: {required_cols}")

        logger.info(f"Loaded {len(df)} emails from {file_path}")
        return df

    except Exception as e:
        logger.error(f"Failed to load dataset: {e}")
        raise

def prepare_training_data(df: pd.DataFrame, 
                         text_col: str = 'text',
                         label_col: str = 'label',
                         test_size: float = 0.2) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Prepare training and validation datasets"""
    from sklearn.model_selection import train_test_split

    # Handle missing labels
    if label_col not in df.columns:
        logger.warning(f"Label column '{label_col}' not found. Creating dummy labels.")
        df[label_col] = 0

    # Split data
    train_df, val_df = train_test_split(
        df, 
        test_size=test_size,
        stratify=df[label_col] if df[label_col].nunique() > 1 else None,
        random_state=42
    )

    logger.info(f"Training set: {len(train_df)} samples")
    logger.info(f"Validation set: {len(val_df)} samples")

    return train_df.reset_index(drop=True), val_df.reset_index(drop=True)
