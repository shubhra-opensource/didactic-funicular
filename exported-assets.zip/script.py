# Create a comprehensive code implementation for the surveillance transition steps
code_content = '''
"""
Market Abuse Surveillance: Lexicon to AI Transition
Complete implementation for long email text analysis
"""

import pandas as pd
import numpy as np
import torch
import re
from transformers import (
    AutoTokenizer, AutoModelForSequenceClassification,
    BertTokenizerFast, AutoModel, AdamW,
    get_linear_schedule_with_warmup
)
from torch.utils.data import Dataset, DataLoader
import torch.nn as nn
import torch.nn.functional as F
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import shap
from small_text import (
    RandomSampler, UncertaintySampler,
    TransformerModelArguments, TransformerBasedClassificationFactory
)
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Dict, Tuple, Optional
import pickle
import logging
from dataclasses import dataclass

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ==================== STEP 1: DATA PREPARATION AND LABELING ====================

class EmailDataProcessor:
    """Handles email data preparation and lexicon-based labeling"""
    
    def __init__(self, lexicon_dict: Dict[str, List[str]]):
        """
        Initialize with lexicon dictionary
        Args:
            lexicon_dict: Dict mapping abuse types to list of keywords
        """
        self.lexicon_dict = lexicon_dict
        self.compiled_patterns = self._compile_patterns()
    
    def _compile_patterns(self) -> Dict[str, List]:
        """Compile regex patterns for efficient matching"""
        compiled = {}
        for abuse_type, keywords in self.lexicon_dict.items():
            patterns = []
            for keyword in keywords:
                # Create case-insensitive pattern with word boundaries
                pattern = re.compile(rf'\\b{re.escape(keyword)}\\b', re.IGNORECASE)
                patterns.append(pattern)
            compiled[abuse_type] = patterns
        return compiled
    
    def extract_lexicon_matches(self, text: str) -> Dict[str, List[Dict]]:
        """
        Extract lexicon matches with positions
        Returns: Dict with abuse types and their matches with positions
        """
        matches = {}
        for abuse_type, patterns in self.compiled_patterns.items():
            type_matches = []
            for pattern in patterns:
                for match in pattern.finditer(text):
                    type_matches.append({
                        'keyword': match.group(),
                        'start': match.start(),
                        'end': match.end(),
                        'context': text[max(0, match.start()-50):match.end()+50]
                    })
            if type_matches:
                matches[abuse_type] = type_matches
        return matches
    
    def create_labeled_dataset(self, emails: List[str], 
                              manual_labels: Optional[List[int]] = None) -> pd.DataFrame:
        """
        Create labeled dataset using lexicon matches and manual labels
        """
        data = []
        for i, email in enumerate(emails):
            matches = self.extract_lexicon_matches(email)
            
            # Lexicon-based label (1 if any matches found, 0 otherwise)
            lexicon_label = 1 if matches else 0
            
            # Use manual label if provided, otherwise use lexicon label
            final_label = manual_labels[i] if manual_labels else lexicon_label
            
            data.append({
                'email_id': i,
                'text': email,
                'lexicon_matches': matches,
                'lexicon_label': lexicon_label,
                'final_label': final_label,
                'text_length': len(email),
                'num_matches': sum(len(v) for v in matches.values())
            })
        
        return pd.DataFrame(data)

# ==================== STEP 2: FEATURE ENGINEERING WITH CONTEXTUAL EMBEDDINGS ====================

class EmailDataset(Dataset):
    """PyTorch Dataset for email classification"""
    
    def __init__(self, texts: List[str], labels: List[int], 
                 tokenizer, max_length: int = 512):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }

# ==================== STEP 3: HYBRID AI MODEL ARCHITECTURE ====================

class FinBERTSurveillance(nn.Module):
    """
    FinBERT-based model with lexicon feature integration
    """
    
    def __init__(self, finbert_model_name: str = 'ProsusAI/finbert',
                 num_classes: int = 2, dropout: float = 0.3):
        super().__init__()
        
        # Load pre-trained FinBERT
        self.finbert = AutoModel.from_pretrained(finbert_model_name)
        
        # Additional layers
        self.dropout = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.finbert.config.hidden_size + 10, num_classes)
        
        # Freeze FinBERT initially (can be unfrozen for fine-tuning)
        for param in self.finbert.parameters():
            param.requires_grad = False
    
    def forward(self, input_ids, attention_mask, lexicon_features=None):
        # Get FinBERT embeddings
        outputs = self.finbert(input_ids=input_ids, attention_mask=attention_mask)
        pooled_output = outputs.pooler_output
        
        # Add lexicon features if provided
        if lexicon_features is not None:
            combined_features = torch.cat([pooled_output, lexicon_features], dim=1)
        else:
            # Pad with zeros if no lexicon features
            batch_size = pooled_output.shape[0]
            zeros = torch.zeros(batch_size, 10).to(pooled_output.device)
            combined_features = torch.cat([pooled_output, zeros], dim=1)
        
        # Classification
        output = self.dropout(combined_features)
        output = self.classifier(output)
        
        return output
    
    def unfreeze_finbert(self):
        """Unfreeze FinBERT for fine-tuning"""
        for param in self.finbert.parameters():
            param.requires_grad = True

# ==================== STEP 4: TRAINING PIPELINE ====================

class SurveillanceTrainer:
    """Training pipeline for surveillance model"""
    
    def __init__(self, model, tokenizer, device='cuda' if torch.cuda.is_available() else 'cpu'):
        self.model = model.to(device)
        self.tokenizer = tokenizer
        self.device = device
        self.training_stats = []
    
    def prepare_lexicon_features(self, texts: List[str], 
                               lexicon_matches: List[Dict]) -> torch.Tensor:
        """
        Create lexicon-based features for each text
        Features: [num_matches, avg_position, max_context_sentiment, ...]
        """
        features = []
        for i, matches in enumerate(lexicon_matches):
            # Basic features
            total_matches = sum(len(v) for v in matches.values())
            
            # Position features
            if total_matches > 0:
                all_positions = []
                for match_list in matches.values():
                    all_positions.extend([m['start'] for m in match_list])
                avg_position = np.mean(all_positions) / len(texts[i])
                min_position = min(all_positions) / len(texts[i])
                max_position = max(all_positions) / len(texts[i])
            else:
                avg_position = min_position = max_position = 0.0
            
            # Abuse type counts
            insider_trading_count = len(matches.get('insider_trading', []))
            market_manipulation_count = len(matches.get('market_manipulation', []))
            spoofing_count = len(matches.get('spoofing', []))
            
            feature_vector = [
                total_matches,
                avg_position,
                min_position,
                max_position,
                insider_trading_count,
                market_manipulation_count,
                spoofing_count,
                len(texts[i]),  # text length
                total_matches / max(len(texts[i]), 1),  # match density
                1.0 if total_matches > 0 else 0.0  # has matches
            ]
            
            features.append(feature_vector)
        
        return torch.tensor(features, dtype=torch.float32)
    
    def train_epoch(self, train_loader, optimizer, scheduler):
        """Train for one epoch"""
        self.model.train()
        total_loss = 0
        correct_predictions = 0
        total_predictions = 0
        
        for batch in train_loader:
            optimizer.zero_grad()
            
            input_ids = batch['input_ids'].to(self.device)
            attention_mask = batch['attention_mask'].to(self.device)
            labels = batch['labels'].to(self.device)
            lexicon_features = batch.get('lexicon_features', None)
            if lexicon_features is not None:
                lexicon_features = lexicon_features.to(self.device)
            
            outputs = self.model(input_ids, attention_mask, lexicon_features)
            loss = F.cross_entropy(outputs, labels)
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            
            total_loss += loss.item()
            predictions = torch.argmax(outputs, dim=1)
            correct_predictions += (predictions == labels).sum().item()
            total_predictions += labels.size(0)
        
        avg_loss = total_loss / len(train_loader)
        accuracy = correct_predictions / total_predictions
        
        return avg_loss, accuracy
    
    def evaluate(self, val_loader):
        """Evaluate the model"""
        self.model.eval()
        total_loss = 0
        correct_predictions = 0
        total_predictions = 0
        all_predictions = []
        all_labels = []
        
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch['input_ids'].to(self.device)
                attention_mask = batch['attention_mask'].to(self.device)
                labels = batch['labels'].to(self.device)
                lexicon_features = batch.get('lexicon_features', None)
                if lexicon_features is not None:
                    lexicon_features = lexicon_features.to(self.device)
                
                outputs = self.model(input_ids, attention_mask, lexicon_features)
                loss = F.cross_entropy(outputs, labels)
                
                total_loss += loss.item()
                predictions = torch.argmax(outputs, dim=1)
                correct_predictions += (predictions == labels).sum().item()
                total_predictions += labels.size(0)
                
                all_predictions.extend(predictions.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
        
        avg_loss = total_loss / len(val_loader)
        accuracy = correct_predictions / total_predictions
        
        return avg_loss, accuracy, all_predictions, all_labels

# ==================== STEP 5: EXPLAINABLE AI IMPLEMENTATION ====================

class SurveillanceExplainer:
    """SHAP-based explainability for surveillance decisions"""
    
    def __init__(self, model, tokenizer, device='cpu'):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.model.eval()
    
    def predict_proba(self, texts):
        """Prediction function for SHAP"""
        self.model.eval()
        probabilities = []
        
        with torch.no_grad():
            for text in texts:
                encoding = self.tokenizer(
                    text,
                    truncation=True,
                    padding='max_length',
                    max_length=512,
                    return_tensors='pt'
                )
                
                input_ids = encoding['input_ids'].to(self.device)
                attention_mask = encoding['attention_mask'].to(self.device)
                
                outputs = self.model(input_ids, attention_mask)
                probs = F.softmax(outputs, dim=1)
                probabilities.append(probs.cpu().numpy()[0])
        
        return np.array(probabilities)
    
    def explain_prediction(self, text: str, num_samples: int = 100):
        """Generate SHAP explanation for a single prediction"""
        # Create SHAP explainer
        explainer = shap.Explainer(self.predict_proba, self.tokenizer)
        
        # Get SHAP values
        shap_values = explainer([text], max_evals=num_samples)
        
        return shap_values
    
    def visualize_explanation(self, text: str, shap_values, save_path: str = None):
        """Create visualization of SHAP explanation"""
        # Force plot
        shap.force_plot(
            shap_values.base_values[0, 1],
            shap_values.values[0, :, 1],
            shap_values.data[0],
            show=False,
            matplotlib=True
        )
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight', dpi=150)
        plt.show()

# ==================== STEP 6: ACTIVE LEARNING IMPLEMENTATION ====================

class ActiveLearningPipeline:
    """Active learning pipeline for continuous model improvement"""
    
    def __init__(self, model, tokenizer, initial_labeled_data, unlabeled_data):
        self.model = model
        self.tokenizer = tokenizer
        self.labeled_data = initial_labeled_data
        self.unlabeled_data = unlabeled_data
        self.query_history = []
    
    def uncertainty_sampling(self, texts: List[str], n_samples: int = 10) -> List[int]:
        """
        Select samples with highest prediction uncertainty
        """
        self.model.eval()
        uncertainties = []
        
        with torch.no_grad():
            for text in texts:
                encoding = self.tokenizer(
                    text,
                    truncation=True,
                    padding='max_length',
                    max_length=512,
                    return_tensors='pt'
                )
                
                input_ids = encoding['input_ids'].to(self.model.device if hasattr(self.model, 'device') else 'cpu')
                attention_mask = encoding['attention_mask'].to(self.model.device if hasattr(self.model, 'device') else 'cpu')
                
                outputs = self.model(input_ids, attention_mask)
                probs = F.softmax(outputs, dim=1)
                
                # Calculate uncertainty (entropy)
                uncertainty = -torch.sum(probs * torch.log(probs + 1e-8), dim=1)
                uncertainties.append(uncertainty.item())
        
        # Get indices of most uncertain samples
        uncertain_indices = np.argsort(uncertainties)[-n_samples:]
        return uncertain_indices.tolist()
    
    def update_model(self, new_labels: List[int], selected_indices: List[int]):
        """Update model with newly labeled data"""
        # Add newly labeled samples to training data
        for idx, label in zip(selected_indices, new_labels):
            sample = {
                'text': self.unlabeled_data[idx],
                'label': label
            }
            self.labeled_data.append(sample)
        
        # Remove from unlabeled data
        self.unlabeled_data = [text for i, text in enumerate(self.unlabeled_data) 
                              if i not in selected_indices]
        
        # Record query
        self.query_history.append({
            'indices': selected_indices,
            'labels': new_labels,
            'timestamp': pd.Timestamp.now()
        })

# ==================== STEP 7: MONITORING AND EVALUATION ====================

class ModelMonitor:
    """Monitor model performance and drift"""
    
    def __init__(self):
        self.metrics_history = []
        self.performance_thresholds = {
            'accuracy': 0.85,
            'precision': 0.80,
            'recall': 0.75,
            'f1': 0.77
        }
    
    def evaluate_model_performance(self, y_true, y_pred, timestamp=None):
        """Evaluate and record model performance"""
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        metrics = {
            'timestamp': timestamp or pd.Timestamp.now(),
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, average='weighted'),
            'recall': recall_score(y_true, y_pred, average='weighted'),
            'f1': f1_score(y_true, y_pred, average='weighted')
        }
        
        self.metrics_history.append(metrics)
        return metrics
    
    def check_performance_drift(self, current_metrics: dict) -> bool:
        """Check if performance has degraded significantly"""
        alerts = []
        
        for metric, threshold in self.performance_thresholds.items():
            if current_metrics[metric] < threshold:
                alerts.append(f"{metric}: {current_metrics[metric]:.3f} < {threshold}")
        
        return len(alerts) > 0, alerts
    
    def plot_performance_trends(self):
        """Plot performance metrics over time"""
        if not self.metrics_history:
            print("No metrics history available")
            return
        
        df = pd.DataFrame(self.metrics_history)
        
        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        axes = axes.ravel()
        
        metrics = ['accuracy', 'precision', 'recall', 'f1']
        for i, metric in enumerate(metrics):
            axes[i].plot(df['timestamp'], df[metric], marker='o')
            axes[i].axhline(y=self.performance_thresholds[metric], 
                           color='r', linestyle='--', alpha=0.7)
            axes[i].set_title(f'{metric.capitalize()} Over Time')
            axes[i].set_ylabel(metric.capitalize())
            axes[i].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        plt.show()

# ==================== STEP 8: COMPLETE PIPELINE INTEGRATION ====================

class SurveillancePipeline:
    """Complete surveillance pipeline integrating all components"""
    
    def __init__(self, lexicon_dict: Dict[str, List[str]]):
        self.lexicon_dict = lexicon_dict
        self.data_processor = EmailDataProcessor(lexicon_dict)
        self.model = None
        self.tokenizer = None
        self.explainer = None
        self.monitor = ModelMonitor()
        self.active_learner = None
        
    def setup_model(self, model_name: str = 'ProsusAI/finbert'):
        """Initialize model and tokenizer"""
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = FinBERTSurveillance(model_name)
        logger.info(f"Model and tokenizer loaded: {model_name}")
    
    def train_initial_model(self, emails: List[str], labels: List[int], 
                           test_size: float = 0.2, epochs: int = 3):
        """Train initial model on labeled data"""
        # Prepare dataset
        df = self.data_processor.create_labeled_dataset(emails, labels)
        
        # Split data
        train_df, val_df = train_test_split(df, test_size=test_size, 
                                          stratify=df['final_label'], 
                                          random_state=42)
        
        # Create data loaders
        train_dataset = EmailDataset(
            train_df['text'].tolist(),
            train_df['final_label'].tolist(),
            self.tokenizer
        )
        
        val_dataset = EmailDataset(
            val_df['text'].tolist(),
            val_df['final_label'].tolist(),
            self.tokenizer
        )
        
        train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
        val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)
        
        # Setup trainer
        trainer = SurveillanceTrainer(self.model, self.tokenizer)
        
        # Setup optimizer and scheduler
        optimizer = AdamW(self.model.parameters(), lr=2e-5, weight_decay=0.01)
        total_steps = len(train_loader) * epochs
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=int(0.1 * total_steps),
            num_training_steps=total_steps
        )
        
        # Training loop
        logger.info("Starting model training...")
        for epoch in range(epochs):
            train_loss, train_acc = trainer.train_epoch(train_loader, optimizer, scheduler)
            val_loss, val_acc, val_preds, val_labels = trainer.evaluate(val_loader)
            
            logger.info(f"Epoch {epoch+1}/{epochs}:")
            logger.info(f"  Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}")
            logger.info(f"  Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}")
            
            # Record metrics
            metrics = self.monitor.evaluate_model_performance(val_labels, val_preds)
            
        logger.info("Training completed!")
        return trainer
    
    def setup_explainability(self):
        """Setup SHAP explainer"""
        if self.model is None:
            raise ValueError("Model must be trained first")
        
        self.explainer = SurveillanceExplainer(self.model, self.tokenizer)
        logger.info("Explainability module initialized")
    
    def process_email(self, email_text: str) -> Dict:
        """Process a single email through the complete pipeline"""
        # Extract lexicon matches
        lexicon_matches = self.data_processor.extract_lexicon_matches(email_text)
        
        # Get AI prediction
        if self.model:
            self.model.eval()
            with torch.no_grad():
                encoding = self.tokenizer(
                    email_text,
                    truncation=True,
                    padding='max_length',
                    max_length=512,
                    return_tensors='pt'
                )
                
                outputs = self.model(encoding['input_ids'], encoding['attention_mask'])
                probabilities = F.softmax(outputs, dim=1)
                ai_prediction = torch.argmax(probabilities, dim=1).item()
                ai_confidence = torch.max(probabilities, dim=1)[0].item()
        else:
            ai_prediction = None
            ai_confidence = None
        
        # Combine results
        result = {
            'email_text': email_text,
            'lexicon_matches': lexicon_matches,
            'lexicon_alert': len(lexicon_matches) > 0,
            'ai_prediction': ai_prediction,
            'ai_confidence': ai_confidence,
            'final_alert': ai_prediction == 1 if ai_prediction is not None else len(lexicon_matches) > 0,
            'explanation': None
        }
        
        # Add explanation if needed
        if self.explainer and result['final_alert']:
            try:
                shap_values = self.explainer.explain_prediction(email_text)
                result['explanation'] = shap_values
            except Exception as e:
                logger.warning(f"Failed to generate explanation: {e}")
        
        return result

# ==================== EXAMPLE USAGE ====================

def create_sample_data():
    """Create sample data for demonstration"""
    # Sample lexicon dictionary
    lexicon_dict = {
        'insider_trading': [
            'inside information', 'confidential deal', 'before announcement',
            'material non-public', 'tip off', 'insider knowledge'
        ],
        'market_manipulation': [
            'pump and dump', 'coordinate buying', 'artificial demand',
            'manipulate price', 'wash trading', 'spoofing'
        ],
        'collusion': [
            'lets coordinate', 'agree on price', 'split the market',
            'fix the rate', 'collude', 'price fixing'
        ]
    }
    
    # Sample email texts (long emails with lexicons in between)
    sample_emails = [
        """
        Dear John,
        
        I hope this email finds you well. I wanted to follow up on our conversation 
        from last week regarding the quarterly projections. The team has been working 
        hard on analyzing the market trends, and we have some interesting findings.
        
        In our analysis, we discovered that there might be some inside information 
        circulating about the upcoming merger. This could significantly impact our 
        strategy moving forward. We should be careful about how we proceed with our 
        trading positions.
        
        Additionally, I wanted to discuss the budget allocation for the next quarter. 
        Please let me know when you're available for a meeting.
        
        Best regards,
        Alice
        """,
        
        """
        Team,
        
        Following our discussion yesterday, I think we need to reconsider our approach 
        to the market. The volatility has been unprecedented, and our current positions 
        may not be optimal.
        
        I suggest we coordinate our buying strategy to ensure we don't compete against 
        each other in the same securities. This will help us achieve better prices 
        and improve our overall performance.
        
        Let's schedule a call for tomorrow to discuss the details.
        
        Thanks,
        Bob
        """,
        
        """
        Hi Sarah,
        
        Thank you for sending the market analysis report. The data looks comprehensive 
        and well-researched. I particularly found the section on emerging markets 
        interesting.
        
        Based on the trends we're seeing, I think we should adjust our portfolio 
        allocation. The technology sector seems to be showing strong fundamentals.
        
        Could you prepare a presentation for next week's board meeting?
        
        Regards,
        Michael
        """
    ]
    
    # Labels: 1 for suspicious, 0 for clean
    sample_labels = [1, 1, 0]
    
    return lexicon_dict, sample_emails, sample_labels

# Demonstration of the pipeline
def demonstrate_pipeline():
    """Demonstrate the complete pipeline"""
    print("=== Market Abuse Surveillance Pipeline Demo ===\\n")
    
    # Create sample data
    lexicon_dict, sample_emails, sample_labels = create_sample_data()
    
    # Initialize pipeline
    pipeline = SurveillancePipeline(lexicon_dict)
    
    # Setup model (Note: This would require actual model files in practice)
    print("Setting up model...")
    # pipeline.setup_model()  # Uncomment when running with actual models
    
    # Demonstrate data processing
    print("Processing sample emails...")
    df = pipeline.data_processor.create_labeled_dataset(sample_emails, sample_labels)
    print(f"Processed {len(df)} emails")
    print("\\nSample processing results:")
    for idx, row in df.iterrows():
        print(f"Email {idx + 1}:")
        print(f"  Length: {row['text_length']} characters")
        print(f"  Lexicon matches: {row['num_matches']}")
        print(f"  Label: {row['final_label']}")
        if row['lexicon_matches']:
            for abuse_type, matches in row['lexicon_matches'].items():
                print(f"    {abuse_type}: {len(matches)} matches")
        print()
    
    return pipeline, df

if __name__ == "__main__":
    # Run demonstration
    pipeline, processed_data = demonstrate_pipeline()
    print("Pipeline demonstration completed!")
    print("\\nNext steps:")
    print("1. Install required packages: transformers, torch, shap, small-text")
    print("2. Download FinBERT model")
    print("3. Prepare your actual email dataset")
    print("4. Train the model using pipeline.train_initial_model()")
    print("5. Setup explainability with pipeline.setup_explainability()")
    print("6. Process new emails with pipeline.process_email()")
'''

# Save the code to a file for download
with open('surveillance_pipeline_complete.py', 'w') as f:
    f.write(code_content)

print("Complete surveillance pipeline code has been created!")
print("File: surveillance_pipeline_complete.py")
print("\nThis implementation includes all 8 steps:")
print("1. Data preparation and labeling")
print("2. Feature engineering with contextual embeddings") 
print("3. Hybrid AI model architecture")
print("4. Training pipeline")
print("5. SHAP-based explainability")
print("6. Active learning implementation")
print("7. Model monitoring and evaluation")
print("8. Complete pipeline integration")