# Create additional utility scripts for specific steps

# 1. Requirements file
requirements_content = '''# Market Abuse Surveillance Pipeline Requirements

# Core ML/NLP libraries
torch>=1.9.0
transformers>=4.15.0
tokenizers>=0.10.0
datasets>=1.18.0

# Data processing
pandas>=1.3.0
numpy>=1.21.0
scikit-learn>=1.0.0

# Explainability
shap>=0.40.0
lime>=0.2.0

# Active Learning
small-text>=1.3.0

# Visualization
matplotlib>=3.5.0
seaborn>=0.11.0
plotly>=5.0.0

# Utilities
tqdm>=4.62.0
loguru>=0.5.0
python-dotenv>=0.19.0

# Optional: For advanced features
scipy>=1.7.0
networkx>=2.6.0  # For graph-based analysis
spacy>=3.4.0     # For NER
'''

with open('requirements.txt', 'w') as f:
    f.write(requirements_content)

# 2. Configuration file
config_content = '''import os
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class ModelConfig:
    """Model configuration settings"""
    finbert_model_name: str = "ProsusAI/finbert"
    max_sequence_length: int = 512
    batch_size: int = 8
    learning_rate: float = 2e-5
    num_epochs: int = 3
    dropout_rate: float = 0.3
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1

@dataclass
class TrainingConfig:
    """Training configuration"""
    test_size: float = 0.2
    validation_size: float = 0.1
    random_state: int = 42
    gradient_clipping: float = 1.0
    save_steps: int = 500
    eval_steps: int = 100

@dataclass 
class ExplainabilityConfig:
    """Explainability configuration"""
    shap_samples: int = 100
    max_display_features: int = 20
    explanation_method: str = "shap"  # "shap" or "lime"

@dataclass
class ActiveLearningConfig:
    """Active learning configuration"""
    initial_samples: int = 100
    query_size: int = 10
    max_iterations: int = 20
    uncertainty_method: str = "entropy"  # "entropy", "margin", "least_confident"

@dataclass
class MonitoringConfig:
    """Model monitoring configuration"""
    performance_thresholds: Dict[str, float] = None
    alert_email: str = "compliance@yourcompany.com"
    monitoring_frequency: str = "daily"  # "hourly", "daily", "weekly"
    
    def __post_init__(self):
        if self.performance_thresholds is None:
            self.performance_thresholds = {
                'accuracy': 0.85,
                'precision': 0.80,
                'recall': 0.75,
                'f1': 0.77
            }

# Default lexicon dictionary for market abuse detection
DEFAULT_LEXICONS = {
    'insider_trading': [
        'inside information', 'confidential deal', 'before announcement',
        'material non-public', 'tip off', 'insider knowledge',
        'private information', 'confidential info', 'material information',
        'non-public information', 'insider tip', 'advance notice'
    ],
    'market_manipulation': [
        'pump and dump', 'coordinate buying', 'artificial demand',
        'manipulate price', 'wash trading', 'spoofing',
        'price manipulation', 'artificial trading', 'fake volume',
        'coordinated trading', 'market corners', 'pump scheme'
    ],
    'collusion': [
        'lets coordinate', 'agree on price', 'split the market',
        'fix the rate', 'collude', 'price fixing',
        'market division', 'coordinate strategy', 'agree to',
        'split territory', 'fix prices', 'coordinate positions'
    ],
    'front_running': [
        'ahead of client', 'front run', 'anticipate order',
        'client flow', 'advance trading', 'pre-position',
        'trade ahead', 'position before', 'client information'
    ]
}

# File paths
class Paths:
    """File path configurations"""
    DATA_DIR = os.path.join(os.getcwd(), 'data')
    MODEL_DIR = os.path.join(os.getcwd(), 'models')
    LOG_DIR = os.path.join(os.getcwd(), 'logs')
    OUTPUT_DIR = os.path.join(os.getcwd(), 'outputs')
    
    # Ensure directories exist
    for directory in [DATA_DIR, MODEL_DIR, LOG_DIR, OUTPUT_DIR]:
        os.makedirs(directory, exist_ok=True)
'''

with open('config.py', 'w') as f:
    f.write(config_content)

# 3. Data preprocessing utilities
preprocessing_utils = '''import pandas as pd
import numpy as np
import re
from typing import List, Dict, Tuple
import logging
from email.parser import Parser
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class EmailTextProcessor:
    """Utility class for processing email texts"""
    
    def __init__(self):
        self.email_regex = re.compile(r'\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b')
        self.phone_regex = re.compile(r'\\b\\d{3}[-.]?\\d{3}[-.]?\\d{4}\\b')
        self.url_regex = re.compile(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
    
    def extract_email_content(self, raw_email: str) -> Dict[str, str]:
        """Extract structured content from raw email"""
        try:
            parser = Parser()
            email_obj = parser.parsestr(raw_email)
            
            content = {
                'subject': email_obj.get('Subject', ''),
                'from': email_obj.get('From', ''),
                'to': email_obj.get('To', ''),
                'date': email_obj.get('Date', ''),
                'body': ''
            }
            
            # Extract body
            if email_obj.is_multipart():
                for part in email_obj.walk():
                    if part.get_content_type() == "text/plain":
                        content['body'] = part.get_payload()
                        break
                    elif part.get_content_type() == "text/html":
                        html_body = part.get_payload()
                        soup = BeautifulSoup(html_body, 'html.parser')
                        content['body'] = soup.get_text()
            else:
                content['body'] = email_obj.get_payload()
            
            return content
            
        except Exception as e:
            logger.error(f"Failed to parse email: {e}")
            return {'body': raw_email, 'subject': '', 'from': '', 'to': '', 'date': ''}
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\\s+', ' ', text)
        
        # Remove email signatures (common patterns)
        text = re.sub(r'--\\n.*$', '', text, flags=re.MULTILINE | re.DOTALL)
        text = re.sub(r'Best regards.*$', '', text, flags=re.MULTILINE | re.DOTALL)
        text = re.sub(r'Sincerely.*$', '', text, flags=re.MULTILINE | re.DOTALL)
        
        # Remove quoted text (replies)
        text = re.sub(r'>.*$', '', text, flags=re.MULTILINE)
        
        return text.strip()
    
    def anonymize_pii(self, text: str) -> str:
        """Remove or anonymize PII from text"""
        # Replace emails
        text = self.email_regex.sub('[EMAIL]', text)
        
        # Replace phone numbers
        text = self.phone_regex.sub('[PHONE]', text)
        
        # Replace URLs
        text = self.url_regex.sub('[URL]', text)
        
        # Replace potential account numbers (8+ consecutive digits)
        text = re.sub(r'\\b\\d{8,}\\b', '[ACCOUNT]', text)
        
        return text
    
    def segment_long_text(self, text: str, max_length: int = 500, overlap: int = 50) -> List[str]:
        """Segment long text into overlapping chunks"""
        if len(text) <= max_length:
            return [text]
        
        segments = []
        start = 0
        
        while start < len(text):
            end = start + max_length
            
            # Try to break at sentence boundary
            if end < len(text):
                sentence_end = text.rfind('.', start, end)
                if sentence_end != -1 and sentence_end > start + max_length // 2:
                    end = sentence_end + 1
            
            segment = text[start:end].strip()
            if segment:
                segments.append(segment)
            
            start = end - overlap
            
            # Prevent infinite loop
            if start >= len(text):
                break
        
        return segments

class LexiconExpander:
    """Expand lexicon terms with variations"""
    
    def __init__(self):
        self.common_variations = {
            'ing': ['', 'ed', 's'],
            'ed': ['', 'ing', 's'],
            's': ['', 'ing', 'ed']
        }
    
    def generate_variations(self, term: str) -> List[str]:
        """Generate common variations of a term"""
        variations = [term]
        
        # Add common misspellings and variations
        words = term.split()
        if len(words) == 1:
            word = words[0]
            
            # Common endings
            for ending, replacements in self.common_variations.items():
                if word.endswith(ending):
                    base = word[:-len(ending)]
                    for replacement in replacements:
                        variations.append(base + replacement)
        
        # Add hyphenated and unhyphenated versions
        if '-' in term:
            variations.append(term.replace('-', ' '))
            variations.append(term.replace('-', ''))
        elif ' ' in term:
            variations.append(term.replace(' ', '-'))
            variations.append(term.replace(' ', ''))
        
        return list(set(variations))
    
    def expand_lexicon(self, lexicon_dict: Dict[str, List[str]]) -> Dict[str, List[str]]:
        """Expand entire lexicon dictionary with variations"""
        expanded = {}
        
        for category, terms in lexicon_dict.items():
            expanded_terms = []
            for term in terms:
                expanded_terms.extend(self.generate_variations(term))
            expanded[category] = list(set(expanded_terms))
        
        return expanded

def load_email_dataset(file_path: str, format: str = 'csv') -> pd.DataFrame:
    """Load email dataset from various formats"""
    try:
        if format.lower() == 'csv':
            df = pd.read_csv(file_path)
        elif format.lower() == 'json':
            df = pd.read_json(file_path)
        elif format.lower() == 'excel':
            df = pd.read_excel(file_path)
        else:
            raise ValueError(f"Unsupported format: {format}")
        
        # Validate required columns
        required_cols = ['text']  # Minimum requirement
        if not all(col in df.columns for col in required_cols):
            raise ValueError(f"Dataset must contain columns: {required_cols}")
        
        logger.info(f"Loaded {len(df)} emails from {file_path}")
        return df
        
    except Exception as e:
        logger.error(f"Failed to load dataset: {e}")
        raise

def prepare_training_data(df: pd.DataFrame, 
                         text_col: str = 'text',
                         label_col: str = 'label',
                         test_size: float = 0.2) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Prepare training and validation datasets"""
    from sklearn.model_selection import train_test_split
    
    # Handle missing labels
    if label_col not in df.columns:
        logger.warning(f"Label column '{label_col}' not found. Creating dummy labels.")
        df[label_col] = 0
    
    # Split data
    train_df, val_df = train_test_split(
        df, 
        test_size=test_size,
        stratify=df[label_col] if df[label_col].nunique() > 1 else None,
        random_state=42
    )
    
    logger.info(f"Training set: {len(train_df)} samples")
    logger.info(f"Validation set: {len(val_df)} samples")
    
    return train_df.reset_index(drop=True), val_df.reset_index(drop=True)
'''

with open('preprocessing_utils.py', 'w') as f:
    f.write(preprocessing_utils)

print("Additional utility files created:")
print("1. requirements.txt - Python dependencies")
print("2. config.py - Configuration settings")
print("3. preprocessing_utils.py - Data preprocessing utilities")