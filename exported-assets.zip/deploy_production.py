#!/usr/bin/env python3
"""
Deployment script for Market Abuse Surveillance Pipeline
This script helps deploy the pipeline in production environments.
"""

import os
import json
import logging
from pathlib import Path
from surveillance_pipeline_complete import SurveillancePipeline
from config import ModelConfig, TrainingConfig, MonitoringConfig
import schedule
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('surveillance_deployment.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ProductionSurveillance:
    """Production deployment wrapper for surveillance pipeline"""

    def __init__(self, config_path: str = "production_config.json"):
        self.config_path = config_path
        self.pipeline = None
        self.load_configuration()
        self.setup_pipeline()

    def load_configuration(self):
        """Load production configuration"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    self.config = json.load(f)
                logger.info(f"Loaded configuration from {self.config_path}")
            else:
                # Create default configuration
                self.config = {
                    "lexicon_dict": {
                        "insider_trading": [
                            "inside information", "confidential deal", "material non-public"
                        ],
                        "market_manipulation": [
                            "pump and dump", "coordinate buying", "artificial demand"
                        ]
                    },
                    "model_name": "ProsusAI/finbert",
                    "monitoring": {
                        "performance_thresholds": {
                            "accuracy": 0.85,
                            "precision": 0.80,
                            "recall": 0.75
                        }
                    },
                    "email_sources": [
                        {"type": "database", "connection": "your_db_connection"},
                        {"type": "file", "path": "/data/emails/"}
                    ]
                }

                # Save default configuration
                with open(self.config_path, 'w') as f:
                    json.dump(self.config, f, indent=2)
                logger.info(f"Created default configuration at {self.config_path}")

        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            raise

    def setup_pipeline(self):
        """Initialize the surveillance pipeline"""
        try:
            self.pipeline = SurveillancePipeline(self.config["lexicon_dict"])

            # Setup model if available
            model_path = self.config.get("model_path")
            if model_path and os.path.exists(model_path):
                self.pipeline.load_trained_model(model_path)
                logger.info("Loaded pre-trained model")
            else:
                logger.warning("No pre-trained model found. Using lexicon-only mode.")

        except Exception as e:
            logger.error(f"Failed to setup pipeline: {e}")
            raise

    def process_new_emails(self):
        """Process newly arrived emails"""
        try:
            logger.info("Processing new emails...")

            # This would connect to your actual email sources
            # For demo, we'll simulate
            new_emails = self.fetch_new_emails()

            alerts = []
            for email in new_emails:
                result = self.pipeline.process_email(email['text'])

                if result['final_alert']:
                    alert = {
                        'email_id': email.get('id'),
                        'timestamp': email.get('timestamp'),
                        'alert_type': 'ai_detected' if result['ai_prediction'] else 'lexicon_detected',
                        'confidence': result.get('ai_confidence', 1.0),
                        'matches': result['lexicon_matches'],
                        'text_preview': email['text'][:200] + '...'
                    }
                    alerts.append(alert)

            # Save alerts
            if alerts:
                self.save_alerts(alerts)
                logger.info(f"Generated {len(alerts)} alerts")

            return alerts

        except Exception as e:
            logger.error(f"Failed to process emails: {e}")
            return []

    def fetch_new_emails(self):
        """Fetch new emails from configured sources"""
        # This is a placeholder - implement based on your email sources
        # Examples:
        # - Database queries
        # - File system monitoring
        # - API calls to email systems

        sample_emails = [
            {
                'id': 'email_' + str(int(time.time())),
                'text': 'Sample email for demonstration',
                'timestamp': time.time(),
                'source': 'demo'
            }
        ]

        return sample_emails

    def save_alerts(self, alerts):
        """Save alerts to configured destination"""
        alerts_file = f"alerts_{int(time.time())}.json"

        try:
            with open(alerts_file, 'w') as f:
                json.dump(alerts, f, indent=2)
            logger.info(f"Saved {len(alerts)} alerts to {alerts_file}")

            # Also send to monitoring system
            self.send_to_monitoring(alerts)

        except Exception as e:
            logger.error(f"Failed to save alerts: {e}")

    def send_to_monitoring(self, alerts):
        """Send alerts to monitoring/alerting system"""
        # Implement integration with your monitoring system
        # Examples:
        # - Send to SIEM
        # - Email notifications
        # - Slack/Teams alerts
        # - Dashboard updates

        high_confidence_alerts = [a for a in alerts if a.get('confidence', 0) > 0.8]
        if high_confidence_alerts:
            logger.warning(f"High confidence alerts detected: {len(high_confidence_alerts)}")

    def health_check(self):
        """Perform system health check"""
        checks = {
            'pipeline_initialized': self.pipeline is not None,
            'model_loaded': hasattr(self.pipeline, 'model') and self.pipeline.model is not None,
            'config_valid': bool(self.config),
            'disk_space': self.check_disk_space(),
            'memory_usage': self.check_memory_usage()
        }

        logger.info(f"Health check results: {checks}")
        return all(checks.values())

    def check_disk_space(self):
        """Check available disk space"""
        import shutil

        _, _, free = shutil.disk_usage(".")
        free_gb = free // (1024**3)
        return free_gb > 1  # At least 1GB free

    def check_memory_usage(self):
        """Check memory usage"""
        import psutil

        memory = psutil.virtual_memory()
        return memory.percent < 85  # Less than 85% memory usage

    def run_monitoring_cycle(self):
        """Run one monitoring cycle"""
        try:
            logger.info("Starting monitoring cycle...")

            # Health check
            if not self.health_check():
                logger.error("Health check failed")
                return

            # Process new emails
            alerts = self.process_new_emails()

            # Performance monitoring (if model is available)
            if self.pipeline.model:
                self.monitor_model_performance()

            logger.info("Monitoring cycle completed successfully")

        except Exception as e:
            logger.error(f"Monitoring cycle failed: {e}")

    def monitor_model_performance(self):
        """Monitor AI model performance"""
        # This would typically involve:
        # - Running model on validation set
        # - Checking for performance drift
        # - Alerting if thresholds are breached

        logger.info("Model performance monitoring - placeholder")

    def start_continuous_monitoring(self):
        """Start continuous monitoring"""
        logger.info("Starting continuous surveillance monitoring...")

        # Schedule regular processing
        schedule.every(5).minutes.do(self.run_monitoring_cycle)
        schedule.every(1).hour.do(self.health_check)

        # Keep running
        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute

        except KeyboardInterrupt:
            logger.info("Monitoring stopped by user")
        except Exception as e:
            logger.error(f"Monitoring failed: {e}")

def deploy_production():
    """Deploy surveillance system in production"""
    print("=== Production Deployment ===\n")

    # Initialize production surveillance
    surveillance = ProductionSurveillance()

    print("Deployment options:")
    print("1. Run single monitoring cycle")
    print("2. Start continuous monitoring")
    print("3. Health check only")
    print("4. Process current email backlog")

    choice = input("\nEnter choice (1-4): ").strip()

    if choice == "1":
        surveillance.run_monitoring_cycle()
    elif choice == "2":
        surveillance.start_continuous_monitoring()
    elif choice == "3":
        health = surveillance.health_check()
        print(f"System health: {'OK' if health else 'ISSUES'}")
    elif choice == "4":
        alerts = surveillance.process_new_emails()
        print(f"Processed emails, generated {len(alerts)} alerts")
    else:
        print("Invalid choice")

if __name__ == "__main__":
    deploy_production()
