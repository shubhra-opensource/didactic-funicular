import os
from dataclasses import dataclass
from typing import Dict, List

@dataclass
class ModelConfig:
    """Model configuration settings"""
    finbert_model_name: str = "ProsusAI/finbert"
    max_sequence_length: int = 512
    batch_size: int = 8
    learning_rate: float = 2e-5
    num_epochs: int = 3
    dropout_rate: float = 0.3
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1

@dataclass
class TrainingConfig:
    """Training configuration"""
    test_size: float = 0.2
    validation_size: float = 0.1
    random_state: int = 42
    gradient_clipping: float = 1.0
    save_steps: int = 500
    eval_steps: int = 100

@dataclass 
class ExplainabilityConfig:
    """Explainability configuration"""
    shap_samples: int = 100
    max_display_features: int = 20
    explanation_method: str = "shap"  # "shap" or "lime"

@dataclass
class ActiveLearningConfig:
    """Active learning configuration"""
    initial_samples: int = 100
    query_size: int = 10
    max_iterations: int = 20
    uncertainty_method: str = "entropy"  # "entropy", "margin", "least_confident"

@dataclass
class MonitoringConfig:
    """Model monitoring configuration"""
    performance_thresholds: Dict[str, float] = None
    alert_email: str = "compliance@yourcompany.com"
    monitoring_frequency: str = "daily"  # "hourly", "daily", "weekly"

    def __post_init__(self):
        if self.performance_thresholds is None:
            self.performance_thresholds = {
                'accuracy': 0.85,
                'precision': 0.80,
                'recall': 0.75,
                'f1': 0.77
            }

# Default lexicon dictionary for market abuse detection
DEFAULT_LEXICONS = {
    'insider_trading': [
        'inside information', 'confidential deal', 'before announcement',
        'material non-public', 'tip off', 'insider knowledge',
        'private information', 'confidential info', 'material information',
        'non-public information', 'insider tip', 'advance notice'
    ],
    'market_manipulation': [
        'pump and dump', 'coordinate buying', 'artificial demand',
        'manipulate price', 'wash trading', 'spoofing',
        'price manipulation', 'artificial trading', 'fake volume',
        'coordinated trading', 'market corners', 'pump scheme'
    ],
    'collusion': [
        'lets coordinate', 'agree on price', 'split the market',
        'fix the rate', 'collude', 'price fixing',
        'market division', 'coordinate strategy', 'agree to',
        'split territory', 'fix prices', 'coordinate positions'
    ],
    'front_running': [
        'ahead of client', 'front run', 'anticipate order',
        'client flow', 'advance trading', 'pre-position',
        'trade ahead', 'position before', 'client information'
    ]
}

# File paths
class Paths:
    """File path configurations"""
    DATA_DIR = os.path.join(os.getcwd(), 'data')
    MODEL_DIR = os.path.join(os.getcwd(), 'models')
    LOG_DIR = os.path.join(os.getcwd(), 'logs')
    OUTPUT_DIR = os.path.join(os.getcwd(), 'outputs')

    # Ensure directories exist
    for directory in [DATA_DIR, MODEL_DIR, LOG_DIR, OUTPUT_DIR]:
        os.makedirs(directory, exist_ok=True)
