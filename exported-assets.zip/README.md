# Market Abuse Surveillance: Lexicon to AI Transition

A complete implementation for transitioning from lexicon-based market abuse detection to AI-powered surveillance systems for long email communications.

## 📋 Overview

This project provides a comprehensive framework for financial institutions to gradually transition from traditional lexicon-based surveillance to advanced AI-powered market abuse detection systems. The implementation specifically handles long email texts where suspicious lexicons may occur anywhere within the content.

## 🏗️ Architecture

The system implements a **hybrid approach** that maintains explainability while dramatically improving detection accuracy:

- **Phase 1**: AI-powered alert triage alongside existing lexicons
- **Phase 2**: Hybrid detection with weakly supervised learning  
- **Phase 3**: AI-primary detection with lexicon validation
- **Phase 4**: Continuous learning and optimization

## 📁 File Structure

```
├── surveillance_pipeline_complete.py  # Main pipeline implementation
├── config.py                         # Configuration settings
├── preprocessing_utils.py             # Data preprocessing utilities
├── example_usage.py                   # Complete usage examples
├── deploy_production.py               # Production deployment script
├── requirements.txt                   # Python dependencies
└── README.md                          # This file
```

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or download the files
pip install -r requirements.txt
```

### 2. Basic Usage

```python
from surveillance_pipeline_complete import SurveillancePipeline
from config import DEFAULT_LEXICONS

# Initialize pipeline
pipeline = SurveillancePipeline(DEFAULT_LEXICONS)

# Process a single email
email_text = """
Dear John, I have some inside information about the upcoming merger.
This confidential deal will be announced next week. We should coordinate 
our trading strategy to take advantage of this opportunity.
"""

result = pipeline.process_email(email_text)
print(f"Alert: {result['final_alert']}")
print(f"Detected patterns: {result['lexicon_matches']}")
```

### 3. Run Complete Example

```bash
python example_usage.py
```

## 🔧 Key Components

### 1. EmailDataProcessor
Handles email data preparation and lexicon-based labeling with position tracking:

```python
processor = EmailDataProcessor(lexicon_dict)
matches = processor.extract_lexicon_matches(email_text)
```

### 2. FinBERTSurveillance Model
Hybrid model combining FinBERT embeddings with lexicon features:

```python
model = FinBERTSurveillance(
    finbert_model_name='ProsusAI/finbert',
    num_classes=2,
    dropout=0.3
)
```

### 3. SurveillanceExplainer
SHAP-based explainability for regulatory compliance:

```python
explainer = SurveillanceExplainer(model, tokenizer)
shap_values = explainer.explain_prediction(email_text)
```

### 4. ActiveLearningPipeline
Continuous improvement through uncertainty sampling:

```python
active_learner = ActiveLearningPipeline(model, tokenizer, labeled_data, unlabeled_data)
uncertain_samples = active_learner.uncertainty_sampling(unlabeled_texts, n_samples=10)
```

## 📊 Features

### ✅ Current Implementation
- **Lexicon-based detection** with position tracking
- **Hybrid AI architecture** ready for FinBERT integration
- **SHAP explainability** for transparent decisions
- **Active learning** framework for continuous improvement
- **Performance monitoring** with drift detection
- **Batch processing** capabilities
- **Production deployment** scripts

### 🔄 Model Training (Requires GPU & Model Files)
To train the AI components, you need:

```python
# Setup model (requires FinBERT download)
pipeline.setup_model('ProsusAI/finbert')

# Train on your data
trainer = pipeline.train_initial_model(emails, labels, epochs=3)

# Setup explainability
pipeline.setup_explainability()
```

## 🎯 Use Cases

### Long Email Analysis
Perfect for analyzing lengthy emails where suspicious terms appear embedded within business communications:

- **Email length**: 500-5000+ characters
- **Mixed content**: Business context + suspicious phrases
- **Context understanding**: AI captures semantic meaning around lexicon matches

### Gradual Transition Strategy
- **Months 1-6**: AI triage of lexicon alerts (60-75% false positive reduction)
- **Months 6-12**: Parallel AI and lexicon detection
- **Months 12-18**: AI-primary with lexicon validation
- **Months 18+**: Full continuous learning deployment

## 📈 Expected Results

Based on industry benchmarks:
- **72% reduction** in false positives
- **4x faster** investigation times
- **Detection of novel abuse patterns** not covered by lexicons
- **Regulatory compliance** through explainable AI

## ⚙️ Configuration

Customize detection patterns in `config.py`:

```python
CUSTOM_LEXICONS = {
    'insider_trading': ['inside information', 'material non-public', 'tip off'],
    'market_manipulation': ['pump and dump', 'coordinate buying', 'artificial demand'],
    'collusion': ['coordinate strategy', 'agree on price', 'fix the rate']
}
```

## 🔍 Monitoring & Alerts

The system includes comprehensive monitoring:

```python
monitor = ModelMonitor()
metrics = monitor.evaluate_model_performance(y_true, y_pred)
drift_detected, alerts = monitor.check_performance_drift(metrics)
```

## 🚀 Production Deployment

```bash
# Production deployment with continuous monitoring
python deploy_production.py
```

Features:
- **Health checks** for system monitoring
- **Automated email processing** from multiple sources  
- **Alert generation** and notification systems
- **Performance monitoring** with threshold alerts

## 🛠️ Customization

### Adding New Abuse Types
```python
custom_lexicons = {
    'front_running': ['ahead of client', 'front run', 'anticipate order'],
    'wash_trading': ['wash trade', 'artificial volume', 'self-trading']
}
```

### Adjusting Model Architecture
```python
model = FinBERTSurveillance(
    finbert_model_name='custom/finbert-model',
    num_classes=3,  # Multi-class classification
    dropout=0.4
)
```

## 📋 Requirements

- Python 3.8+
- PyTorch 1.9+
- Transformers 4.15+
- SHAP 0.40+
- GPU recommended for model training

## 🤝 Integration

The pipeline integrates with:
- **Email systems** (Exchange, Gmail, custom)
- **Databases** (PostgreSQL, MongoDB)
- **SIEM systems** for alert routing
- **Monitoring tools** (Prometheus, Grafana)

## 📝 Regulatory Compliance

- **Explainable AI** with SHAP and LIME
- **Audit trails** for all decisions
- **Performance documentation** for supervisors
- **Graduated rollout** maintaining compliance during transition

## 🔒 Security & Privacy

- **PII anonymization** in preprocessing
- **Secure model storage** and access controls
- **Audit logging** for all processing activities
- **Data retention** policies for compliance

## 📞 Support

For implementation support:
1. Review `example_usage.py` for complete examples
2. Check `config.py` for customization options  
3. Use `preprocessing_utils.py` for data preparation
4. Deploy with `deploy_production.py` for production use

## 🚨 Important Notes

1. **GPU Required**: Model training requires GPU acceleration
2. **Data Privacy**: Ensure email data compliance with local regulations
3. **Gradual Rollout**: Recommended phased implementation approach
4. **Model Updates**: Regular retraining needed for evolving abuse patterns
5. **Regulatory Approval**: Coordinate with compliance teams before deployment

## 📈 Next Steps

1. Prepare your email dataset
2. Install dependencies and download FinBERT
3. Train initial model on labeled data
4. Deploy Phase 1 (AI triage) alongside existing lexicons
5. Gradually transition to full AI-powered detection